package com.example.taks51c;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements placetogoAdapter.OnRowClickListener {
    RecyclerView topRecyclerView;
    topimageAdapter topimageAdapter;
    List<topimage> topimageList = new ArrayList<>();

    RecyclerView placetogoRecyclerView;
    placetogoAdapter placetogoAdapter;
    List<placetogo> placetogoList = new ArrayList<>();

    Integer[] imageList = {R.drawable.image1,R.drawable.image2,R.drawable.image3,R.drawable.image4,R.drawable.image5};

    Integer[] imageList2 = {R.drawable.image6,R.drawable.image7,R.drawable.image8,R.drawable.image9};
    String[] placename = {"State Library","Flinder Street Station","Eureka Tower","Shine of Rememberance"};
    String[] placebrief = {"State Library of Victoria","The oldest rail way station in Melbourne","The Highest building in Melbourne",
                            "Melbourne War Memorial"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        topRecyclerView = findViewById(R.id.TopdestRecyclerView);
        placetogoRecyclerView = findViewById(R.id.PlacetogoRecyler);

        topimageAdapter = new topimageAdapter(topimageList,MainActivity.this);
        topRecyclerView.setAdapter(topimageAdapter);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        topRecyclerView.setLayoutManager(layoutManager);

        for(int i=0; i<imageList.length;i++){
            topimage topimage = new topimage(i,imageList[i]);
            topimageList.add((topimage));
        }

        placetogoAdapter = new placetogoAdapter(placetogoList,MainActivity.this,this);
        placetogoRecyclerView.setAdapter(placetogoAdapter);
        RecyclerView.LayoutManager layoutManager1 = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        placetogoRecyclerView.setLayoutManager(layoutManager1);

        for (int i=0; i<imageList2.length;i++){
            placetogo placetogo = new placetogo(i,imageList2[i],placename[i],placebrief[i]);
            placetogoList.add(placetogo);
        }


    }

    @Override
    public void onItemClick(int position) {
        Fragment fragment;
        switch (position){
            case 0:
                fragment = new FirstFragment();
                break;
            case 1:
                fragment = new SecondFragment();
                break;
            case 2:
                fragment = new ThirdFragment();
                break;
            case 3:
                fragment = new FourthFragment();
                break;

            default:
                throw new IllegalStateException("Unexpected value: " + position);
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment,fragment).addToBackStack("1").commit();

    }
}