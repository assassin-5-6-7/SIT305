package com.example.taks51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class topimageAdapter extends RecyclerView.Adapter<topimageAdapter.topimageViewHolder> {
    private List<topimage> topimageList;
    private Context context;
    public topimageAdapter(List<topimage> topimageList,Context context){
        this.topimageList = topimageList;
        this.context = context;
    }

    @NonNull
    @Override
    public topimageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.topdestination,parent,false);
        return new topimageViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull topimageViewHolder holder, int position) {
        holder.topdestView.setImageResource(topimageList.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return topimageList.size();
    }

    public class topimageViewHolder extends RecyclerView.ViewHolder{
        public ImageView topdestView;


        public topimageViewHolder(@NonNull View itemView) {
            super(itemView);
            topdestView = itemView.findViewById(R.id.topdestView);
        }
    }
}
