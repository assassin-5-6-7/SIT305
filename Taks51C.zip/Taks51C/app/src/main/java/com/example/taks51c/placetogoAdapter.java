package com.example.taks51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class placetogoAdapter extends RecyclerView.Adapter<placetogoAdapter.placetogoHolder> {
    private List<placetogo> placetogoList;
    private Context context;
    private OnRowClickListener listener;


    public placetogoAdapter(List<placetogo> placetogoList, Context context, OnRowClickListener clickListener) {
        this.placetogoList = placetogoList;
        this.context = context;
        this.listener = clickListener;
    }

    @NonNull
    @Override
    public placetogoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.placetogo,parent,false);

        return new placetogoHolder(itemView,listener);
    }

    @Override
    public void onBindViewHolder(@NonNull placetogoHolder holder, int position) {
        holder.placeImageView.setImageResource(placetogoList.get(position).getImage());
        holder.Placename.setText(placetogoList.get(position).getName());
        holder.Placebrief.setText(placetogoList.get(position).getBrief());

    }

    @Override
    public int getItemCount() {
        return placetogoList.size();
    }

    public class placetogoHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public ImageView placeImageView;
        public TextView Placename;
        public TextView Placebrief;
        public OnRowClickListener onRowClickListener;

        public placetogoHolder(@NonNull View itemView, OnRowClickListener onRowClickListener) {
            super(itemView);
            placeImageView = itemView.findViewById(R.id.placeimageView);
            Placename = itemView.findViewById(R.id.placename);
            Placebrief = itemView.findViewById(R.id.placebrief);
            this.onRowClickListener = onRowClickListener;
            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View v) {
            onRowClickListener.onItemClick(getAdapterPosition());
        }
    }
    public interface OnRowClickListener{
        void onItemClick(int position);
    }

}
