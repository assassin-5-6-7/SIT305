package com.example.taks51c;

public class topimage {
    public topimage(int id, int image){
        this.id = id;
        this.image = image;
    }


    private int id,image;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.image = id;
    }

    public int getImage(){
        return image;
    }
    public void  setImage(int image){
        this.image = image;
    }



}
