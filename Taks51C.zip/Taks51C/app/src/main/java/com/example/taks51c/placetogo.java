package com.example.taks51c;

public class placetogo {
    private int id,image;
    private String name,brief;

    public placetogo(int id, int image, String name, String brief) {
        this.id = id;
        this.image = image;
        this.name = name;
        this.brief = brief;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }
}
