
//By Yuxing.Ding 2021
//dingyux@deakin.edu.au
package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Create instance of my widgets
    EditText Input;
    TextView value1,value2,value3,unit1,unit2,unit3,welcome;
    Spinner spinner;
    String nowunit; //This value is for store the value from the spinner.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);     //Link to the widgets from XML file
        Input = findViewById(R.id.Insertparameter);
        value1 = findViewById(R.id.valueText1);
        value2 = findViewById(R.id.valueText2);
        value3 = findViewById(R.id.valueText3);
        unit1 = findViewById(R.id.UnitText1);
        unit2 = findViewById(R.id.UnitText2);
        unit3 = findViewById(R.id.UnitText3);
        spinner = findViewById(R.id.onlyspinner);
        welcome = findViewById(R.id.welcome);

        //Declear a array adpter instence
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,R.array.data, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); //Set the adapter's dropdown layout
        spinner.setAdapter(adapter);
        spinner.setPrompt("Unit");      //This a prompt of spinner, can be seen as a title
        spinner.setOnItemSelectedListener(new SpinnerOnselectedListener());    // Set the setOnItemSelectedListener method of spinner, need a class implement from OnItemSelectedListed

    }


    //Method of Lenthcoverter
    public void Lenthconvert(View view) {
        welcome.setText("");
        if (nowunit.equals("metre")) {
            try{                                                                    //try..catch block is used for catch input mistake, like not a number
            double result1 = Double.parseDouble(Input.getText().toString()) * 100;
            double result2 = Double.parseDouble(Input.getText().toString()) * 3.28;
            double result3 = Double.parseDouble(Input.getText().toString()) * 39.37;
            value1.setText(String.format("%.2f", result1));
            value2.setText(String.format("%.2f", result2));
            value3.setText(String.format("%.2f", result3));
            unit1.setText("Centimetre");
            unit2.setText("Foots");
            unit3.setText("Inch");}
            catch (Exception e){
                Toast.makeText(MainActivity.this, "Input Errr", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(MainActivity.this, "Please Select the right unit", Toast.LENGTH_SHORT).show(); //if the unit has not been selected right, will prompt the user
        }
    }

    //method of weightcovert
    public void weightconvert(View view) {
        welcome.setText("");
        if (nowunit.equals("kilogram")) {
            try {
                double result1 = Double.parseDouble(Input.getText().toString()) * 1000;
                double result2 = Double.parseDouble(Input.getText().toString()) * 35.27;
                double result3 = Double.parseDouble(Input.getText().toString()) * 2.20;
                value1.setText(String.format("%.2f", result1));
                value2.setText(String.format("%.2f", result2));
                value3.setText(String.format("%.2f", result3));
                unit1.setText("Gram");
                unit2.setText("Ounce(Oz)");
                unit3.setText("Pound(lb)");
            }
            catch (Exception e)
            {
                Toast.makeText(MainActivity.this, "Input Error", Toast.LENGTH_SHORT).show();
            }

        }
        else {
            Toast.makeText(MainActivity.this, "Please Select the right unit", Toast.LENGTH_SHORT).show();
        }
    }

    //method of tempreture converter
    public void Temconvert(View view) {
        welcome.setText("");
        if (nowunit.equals("celsius")) {
            try {
            double result1 = Double.parseDouble(Input.getText().toString()) * 33.8;
            double result2 = Double.parseDouble(Input.getText().toString()) * 274.15;
            value1.setText(String.format("%.2f", result1));
            value2.setText(String.format("%.2f", result2));
            value3.setText("");
            unit1.setText("Fahrenheit");
            unit2.setText("Kelvin");
            unit3.setText("");}
            catch (Exception e)
            {
                Toast.makeText(MainActivity.this, "Input Error", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(MainActivity.this, "Please Select the right unit", Toast.LENGTH_SHORT).show();
        }
    }

    //SpinnerOnselectedListener class

    private class SpinnerOnselectedListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String selected = parent.getItemAtPosition(position).toString();
            Toast.makeText(parent.getContext(),selected,Toast.LENGTH_SHORT).show();

            nowunit = selected.toLowerCase();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
}