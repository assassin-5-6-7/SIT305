//By Yuxing Ding 2021
//dingyux@deakin.edu.au
package com.example.timer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    TextView information,time;
    ImageButton start,pause,stop;
    EditText workout;

    Timer timer;
    TimerTask task;


    int hour,minute,second;

    boolean started;

    SharedPreferences sharedPreferences;
    SharedPreferences sharedPreferences2;
    String WORK_OUT,WORK_OUTTIME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        workout = findViewById(R.id.Workouttype);
        information = findViewById(R.id.information);
        time = findViewById(R.id.Timer);
        start = findViewById(R.id.StartButton);
        pause = findViewById(R.id.PauseButton);
        stop = findViewById(R.id.StopButton);

        hour = 0;
        minute = 0;
        second = 0;
        started = false;

        timer = new Timer();


        //preferences
        sharedPreferences = getSharedPreferences("com.example.timer",MODE_PRIVATE);
        sharedPreferences2 = getSharedPreferences("abc",MODE_PRIVATE);
        checkshared();


        if(savedInstanceState != null){
            hour = savedInstanceState.getInt("hour");
            minute = savedInstanceState.getInt("min");
            second = savedInstanceState.getInt("sec");
            started = savedInstanceState.getBoolean("state");
        }
        if(started == true){
            startTimer();
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("hour",hour);
        outState.putInt("min",minute);
        outState.putInt("sec",second);
        outState.putBoolean("state",started);
    }

    public void checkshared(){
        String workout = sharedPreferences.getString(WORK_OUT,"");
        String workouttime = sharedPreferences2.getString(WORK_OUTTIME,"");
        information.setText("You spent "+workouttime+" on "+workout+" last time.");

    }


    public void Pause(View view) {
        if (started==true){
            task.cancel();
            started = false;
        }
        else{
            Toast.makeText(this,"start first!",Toast.LENGTH_LONG).show();
        }


    }

    public void stop(View view) {
        if(started==true){
            task.cancel();
            String timenow = String.format("%02d:%02d:%02d",hour,minute,second);
            time.setText(timenow);
            started = false;
            //add value to sharepref
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(WORK_OUT, workout.getText().toString());
            editor.apply();

            SharedPreferences.Editor editor1 = sharedPreferences2.edit();
            editor1.putString(WORK_OUTTIME,timenow);
            editor1.apply();

        }
        else{
            String timenow = String.format("%02d:%02d:%02d",hour,minute,second);
            time.setText(timenow);
            started = false;
            //add value to sharepref
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(WORK_OUT, workout.getText().toString());
            editor.apply();

            SharedPreferences.Editor editor1 = sharedPreferences2.edit();
            editor1.putString(WORK_OUTTIME,timenow);
            editor1.apply();
        }


    }

    public void StartButton(View view) {
        if (started==false){
            startTimer();
            started = true;
        }
        else{
            Toast.makeText(this,"Alreadly started!",Toast.LENGTH_LONG).show();
        }


    }

    //This method is for counting time,
    //create a timertask it can do that.
    //timertask is another thread!!!!
    private void startTimer() {
        task = new TimerTask() {
            @Override
            public void run() {
                if(second==59){
                    second = 0;
                    minute++;
                    if (minute==59){
                        minute = 0;
                        hour++;
                    }
                }
                second++;
                String timenow = String.format("%02d:%02d:%02d",hour,minute,second);
                time.setText(timenow);

            }
        };
        timer.schedule(task,0,1000); //set the delay and period for task.
    }
}