//by Yuxing Ding
package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);

        Intent intent = getIntent();
        String namr2 = intent.getStringExtra("Globalname");
        name.setText(namr2);

    }

    public void StartClick(View view) {
        Intent intent = new Intent(this,Quizquestion.class);
        intent.putExtra("name",name.getText().toString());
        startActivity(intent);
        finish();
    }
}