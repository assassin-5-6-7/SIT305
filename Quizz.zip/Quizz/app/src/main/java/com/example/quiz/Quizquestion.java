package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Quizquestion extends AppCompatActivity {

    TextView welcome;

    Button answer1;
    Button submit;
    Button answer2;
    Button answer3;
    TextView title;
    TextView question;
    TextView progrees;
    ProgressBar progressBar;

    boolean answered = false;
    boolean sb = false;
    Integer count = 0;
    Integer current = count+1;

    String[] titlelist = {"Android Architecture","User interface","Hook the resoureces","Activity Lifecycle",
            "Switch Activity"
    };
    String[] Questionlist = {"How many Architectures in Android system?",
            "What is used to define the structure for a user interface?",
            "By using what code you can hook the resoureces and java?",
            "Which of the following is not in the Android activity lifecycle?",
            "What will be used to swich from one activity to another?"};
    String[] choose1 = {"3","Layout","P.java","Pause","goto"};
    String[] choose2 = {"5","View","R.java","Start","intent"};
    String[] choose3 = {"6","ViewGroup","H.java","Continue","switch"};
    String[] rignt = {"6","Layout","R.java","Continue","intent"};
    Integer Userchoose;


    String globalname = "aaa";
    Integer Result = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quizquestion);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        globalname = name;
        welcome = findViewById(R.id.welcome);
        welcome.setText("Welcome "+name);

        answer1 = findViewById(R.id.Answer1);
        answer2 = findViewById(R.id.answer);
        answer3 = findViewById(R.id.answer2);
        title = findViewById(R.id.questiontitle);
        question = findViewById(R.id.questionbody);
        submit = findViewById(R.id.submit);
        progrees = findViewById(R.id.progress);
        progressBar = findViewById(R.id.progressBar);

        init();


        submit.setOnClickListener(new SubmitButtonListener());
        answer1.setOnClickListener(new Answer1buttonListener());
        answer2.setOnClickListener(new Answer2buttonListener());
        answer3.setOnClickListener(new Answer3buttonListener());





        //answer2.setBackgroundResource(R.drawable.correct_button);
        //answer1.setBackgroundResource(R.drawable.wrong_button);
        //submit.setBackgroundResource(R.drawable.wrong_button);
        //answer3.setBackgroundResource(R.drawable.custom_button);
    }

    public void init(){
        title.setText(titlelist[count]);
        question.setText(Questionlist[count]);
        answer1.setText(choose1[count]);
        answer2.setText(choose2[count]);
        answer3.setText(choose3[count]);
        answer1.setBackgroundResource(R.drawable.custom_button2);
        answer2.setBackgroundResource(R.drawable.custom_button2);
        answer3.setBackgroundResource(R.drawable.custom_button2);
        progrees.setText(current.toString()+"/5");
        progressBar.setProgress(current);
    }


    private class SubmitButtonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if(answered){
                if(!sb){
                    sb = true;
                    submit.setText("Next");
                    if (Userchoose == 1){
                        if (choose1[count].equals(rignt[count])){
                            answer1.setBackgroundResource(R.drawable.correct_button);
                            Result++;
                        }
                        else{
                            answer1.setBackgroundResource(R.drawable.wrong_button);
                            if(choose2[count].equals(rignt[count])){
                                answer2.setBackgroundResource(R.drawable.correct_button);
                            }
                            else {
                                answer3.setBackgroundResource((R.drawable.correct_button));
                            }
                        }
                    }
                    else if (Userchoose == 2){
                        if (choose2[count].equals(rignt[count])){
                            answer2.setBackgroundResource(R.drawable.correct_button);
                            Result++;
                        }
                        else{
                            answer2.setBackgroundResource(R.drawable.wrong_button);
                            if(choose1[count].equals(rignt[count])){
                                answer1.setBackgroundResource(R.drawable.correct_button);
                            }
                            else {
                                answer3.setBackgroundResource((R.drawable.correct_button));
                            }
                        }

                    }
                    else if (Userchoose == 3){
                        if (choose3[count].equals(rignt[count])){
                            answer3.setBackgroundResource(R.drawable.correct_button);
                            Result++;
                        }
                        else{
                            answer3.setBackgroundResource(R.drawable.wrong_button);
                            if(choose2[count].equals(rignt[count])){
                                answer2.setBackgroundResource(R.drawable.correct_button);
                            }
                            else {
                                answer1.setBackgroundResource((R.drawable.correct_button));
                            }
                        }
                    }
                }
                else{
                    if(count==4){
                        Intent intent = new Intent(Quizquestion.this,Result.class);
                        intent.putExtra("globalname",globalname);
                        intent.putExtra("result",Result);
                        startActivity(intent);
                        finish();

                    }
                    else {
                        sb = false;
                        submit.setText("Submit");
                        count++;
                        current++;
                        answered = false;
                        init();
                    }

                }
            }
            else{
                Toast.makeText(Quizquestion.this,"answer first",Toast.LENGTH_LONG).show();
            }
        }
    }

    private class Answer1buttonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if(!sb) {
                init();
                answered = true;
                answer1.setBackgroundResource(R.drawable.custom_button);
                Userchoose = 1;

            }
        }
    }

    private class Answer2buttonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if(!sb) {
                init();
                answered = true;
                answer2.setBackgroundResource(R.drawable.custom_button);
                Userchoose = 2;
            }
        }
    }

    private class Answer3buttonListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            if (!sb) {
                init();
                answer3.setBackgroundResource(R.drawable.custom_button);
                answered = true;
               Userchoose = 3;
            }
        }
    }
}