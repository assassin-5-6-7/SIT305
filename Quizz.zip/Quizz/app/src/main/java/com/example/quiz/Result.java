package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Result extends AppCompatActivity {

    TextView congrats;
    TextView Score;
    String Globalname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        Intent intent = getIntent();
        String name = intent.getStringExtra("globalname");
        Globalname = name;
        Integer Result = intent.getIntExtra("result",0);
        congrats = findViewById(R.id.congrats);
        congrats.setText("Congratulations "+name);
        Score = findViewById(R.id.Score);
        Score.setText(Result.toString()+"/5");

    }

    public void Restartclick(View view) {
        Intent intent = new Intent(this,MainActivity.class);
        intent.putExtra("Globalname",Globalname);
        startActivity(intent);
        finish();
    }


    public void Exit(View view) {
        finish();
    }
}